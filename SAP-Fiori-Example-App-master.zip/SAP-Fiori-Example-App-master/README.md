SAPUI5-Fiori
============

This is a test Fiori App using using google maps.
The idea is that search search for a product and than finds the store with the availibity of the article 
and this places the store location on the map.

ToDos
------
1) Proper Service Search inteation (re issuing the json query)
2) passing the the Plant address information to the lineitem screen
... mmany more ...

Modified by Markus - mvk@ca.ibm.com


More Information
------------------
[SAPUI5](scn.sap.com/community/developer-center/front-end) is the HTML5 UI framework from SAP. [OpenUI5](http://sap.github.io/openui5/) (here on Github) is the open source version. 

Details
-------
The app uses a Component based MVC approach.

On top of the original sources, I have added experimental comparisons between different view sources, in different branches of this repo:

- [XML](https://github.com/qmacro/SAPUI5-Fiori/tree/master)
- [JavaScript](https://github.com/qmacro/SAPUI5-Fiori/tree/js)
- [CoffeeScript](https://github.com/qmacro/SAPUI5-Fiori/tree/coffee)

plus CoffeeScript sources for other JavaScript files (such as controllers).
